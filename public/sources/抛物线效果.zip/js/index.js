$('.items').flyto({
  item      : 'li',
  target    : '.cart',
  button    : '.my-btn'
});