A Pen created at CodePen.io. You can find this one at http://codepen.io/liuheng/pen/grjJOj.

 jQuery lightweight plugin Fly to.

### [Download as zip](https://dl.dropboxusercontent.com/u/70204595/plugins/flyto/src/flyto.zip)
[version 1](http://codepen.io/ElmahdiMahmoud/details/tEeDn)

*Repository and documentation will be available soon*